package ru.dz.mqtt_udp.io;

public abstract class GeneralAddress implements IPacketAddress {

}
