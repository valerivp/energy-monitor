/**
 * <p>Remote configuration support</p> 
 * @author dz
 *
 */
package ru.dz.mqtt_udp.config;