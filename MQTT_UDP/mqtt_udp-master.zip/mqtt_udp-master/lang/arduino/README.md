# Arduino specific C code

Add library in MQTT_UDP to your Arduino IDE, open UdpPublish_MQTT sketch.
There must be Ethernet module connected. I used ENC28J60, 
see [hardware connections](https://github.com/UIPEthernet/UIPEthernet/tree/master/hardware)
for more details.

## See also

<https://github.com/UIPEthernet/UIPEthernet/blob/master/examples/UdpServer/UdpServer.ino>

