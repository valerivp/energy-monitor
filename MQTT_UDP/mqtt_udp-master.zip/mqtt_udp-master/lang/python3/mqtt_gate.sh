#!/bin/sh
cd examples
python mqtt_bidir_gate.py &
