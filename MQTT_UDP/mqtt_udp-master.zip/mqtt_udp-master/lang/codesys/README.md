# Codesys 

Structured text language implementation.

NB! **Send only for now.**

Send - MQTT_UDP_SEND.EXP 

Listen (NOT TESTED!) - MQTT_UDP_LISTEN.EXP 
