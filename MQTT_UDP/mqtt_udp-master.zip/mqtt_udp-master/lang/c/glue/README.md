# How to set up compilation for non-defailt OS

## If we already have a subdir for your environment

Copy Makefile.glue.local.in to Makefile.glue.local and modify
settings accotding to local paths

## If there is no ready made subdir

Make a copy of one of sibling directories and modify code
according to target OS or lib

