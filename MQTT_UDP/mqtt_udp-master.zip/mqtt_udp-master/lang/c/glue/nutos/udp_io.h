
// all includes needed for UDP IO to compile

#include <inttypes.h>
#include <string.h>
#include <stdio.h>

// NutOS

#include <sys/socket.h>
#include <sys/event.h>
