*   Used lua version independend `bit` impl from: <https://github.com/xHasKx/luamqtt>
