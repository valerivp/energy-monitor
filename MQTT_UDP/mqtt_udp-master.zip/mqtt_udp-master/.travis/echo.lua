#!/usr/bin/lua

print( "package.path="..package.path )
