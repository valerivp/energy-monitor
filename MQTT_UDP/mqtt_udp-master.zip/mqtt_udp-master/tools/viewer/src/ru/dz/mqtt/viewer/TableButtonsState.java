package ru.dz.mqtt.viewer;

public class TableButtonsState {

	private boolean limitSendToHost = false;
	
	public boolean isLimitSendToHost() { return limitSendToHost;	}
	public void setLimitSendToHost(boolean limitSendToHost) {		this.limitSendToHost = limitSendToHost;	}
	
}
