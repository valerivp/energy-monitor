#!/bin/sh
java -jar ConfigServer.jar 
