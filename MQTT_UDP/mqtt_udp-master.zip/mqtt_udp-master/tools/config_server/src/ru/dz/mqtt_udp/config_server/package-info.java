/**
 *
 * <p>
 * 
 * Remote configuration server.
 * 
 * <p>
 * 
 * @author dz
 *
 */
package ru.dz.mqtt_udp.config_server;