/**
 * <p>Image utilities - load icon from file/JAR</p>
 * 
 * @author dz
 *
 */
package ru.dz.mqtt_udp.util.image;