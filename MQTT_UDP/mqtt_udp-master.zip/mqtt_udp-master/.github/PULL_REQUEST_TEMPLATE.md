Fixes #

## Fixed/implemented in

-   [ ] Pyhon implementation
-   [ ] Java implementation
-   [ ] Java tools
-   [ ] C implementation/Unix
-   [ ] C implementation/Embedded
-   [ ] Lua implementation
-   [ ] CodeSys implementation


## Proposed Changes

  -
  -
  -

