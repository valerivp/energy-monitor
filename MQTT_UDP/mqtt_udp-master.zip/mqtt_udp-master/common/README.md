# Multilanguage and language independent content and definitions

